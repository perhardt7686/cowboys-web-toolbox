/* Street r0d Engineering V2 supplement | original fictional vehicles.
 * Non-destructive extension of existing The Commons Street r0d game.
 * Requires server migrations streetrod_engineering_v2 (+ specs, last-run telemetry).
 * Only a signed-in, approved member may call the authenticated server RPCs.
 * No credentials, database policies, game scores, or saved race records in this file.
 */
import {createAuthStorage} from './auth-flow.mjs?v=recovery1';

const cfg = window.COWBOY_COMMUNITY_CONFIG;
const esc = value => String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
const asNumber = (value, fallback = 0) => Number.isFinite(Number(value)) ? Number(value) : fallback;
const formatTime = value => value == null ? '—' : `${(Number(value) / 1000).toFixed(2)} s`;
const formatNumber = value => Math.round(asNumber(value)).toLocaleString('en-US');
const clamp = (value, lo, hi) => Math.max(lo, Math.min(hi, value));
const CARS = Object.freeze({
  rattler: {name:'Rattler 48', body:'Chopped 1940s hot rod', year:'48', color:'#efc06b'},
  comet: {name:'Comet 55', body:'Lightweight 1950s speed coupe', year:'55', color:'#72d7d3'},
  nomad: {name:'Nomad 63', body:'Sleeper-style 1960s wagon', year:'63', color:'#bc99ef'},
  meteor: {name:'Meteor 67', body:'Long-hood muscle fastback', year:'67', color:'#fb7778'},
  phantom: {name:'Phantom X', body:'Wide-body drag prototype', year:'X', color:'#f3d184'}
});

/* These are fictional designs rather than copies of any production vehicles. */
function carArtwork(key, size = 'wide') {
  const car = CARS[key] || CARS.rattler;
  const shapes = {
    rattler: {
      shell:'M25 86 L24 72 Q26 66 39 65 L64 63 L79 43 Q85 34 99 33 L157 33 Q173 35 183 47 L197 60 L248 60 Q264 61 271 70 L301 72 L312 84 L309 102 L27 102 Z',
      cabin:'M87 62 L99 40 L154 39 Q165 39 175 51 L181 61 Z',
      trim:'M30 83 Q72 75 90 78 L197 78 L250 75 L302 83',
      extra:'<path d="M53 67 Q65 53 78 65" fill="none" stroke="#ffe7bc" stroke-width="5"/><path d="M244 62 l29 -10 m-20 15 31 -4" stroke="#121521" stroke-width="5"/><path d="M246 62 l27 -11 m-16 13 24 -3" stroke="#d9dbe4" stroke-width="2"/><circle cx="303" cy="83" r="8" fill="#f8eecb" stroke="#d5b374" stroke-width="3"/>'
    },
    comet: {
      shell:'M16 91 L19 75 Q23 68 45 68 L74 64 L102 46 Q116 40 143 41 L181 44 L210 66 L271 70 Q294 72 303 82 L310 91 L304 102 L20 102 Z',
      cabin:'M98 65 L114 48 Q122 44 141 45 L178 47 L197 65 Z',
      trim:'M23 82 Q71 89 111 82 Q202 78 294 85',
      extra:'<path d="M49 88 L105 88 Q174 95 219 82 L288 83" fill="none" stroke="#fef8dc" stroke-width="4"/><path d="M50 75 L84 75 M249 76 L278 79" stroke="#fff8eb" stroke-width="3"/>'
    },
    nomad: {
      shell:'M18 91 L20 65 L62 62 L78 38 L232 39 L246 66 L289 70 L309 83 L309 103 L19 103 Z',
      cabin:'M82 65 L93 43 L153 43 L153 65 Z M158 43 L225 43 L239 65 L158 65 Z',
      trim:'M26 78 L301 78',
      extra:'<path d="M95 34 L225 34 M104 31 L104 37 M212 31 L212 37" stroke="#dad5d8" stroke-width="3"/><path d="M42 89 L271 89" stroke="#dcb07f" stroke-width="6"/><path d="M158 65 L158 96 M241 65 L241 97" stroke="#dce2e7" stroke-width="3"/>'
    },
    meteor: {
      shell:'M12 88 L19 72 Q32 65 81 65 L106 43 Q119 36 140 37 L176 37 L229 64 L288 66 L314 81 L308 104 L18 104 Z',
      cabin:'M107 64 L121 43 L174 43 L208 64 Z',
      trim:'M24 86 L308 86',
      extra:'<path d="M55 68 L101 68 M235 74 L287 73" stroke="#f8e3d0" stroke-width="4"/><path d="M155 42 L191 64" stroke="#141a29" stroke-width="6"/><path d="M77 70 l29 -8 43 0" fill="none" stroke="#281d28" stroke-width="4"/>'
    },
    phantom: {
      shell:'M8 94 L25 81 L65 78 L102 62 L129 48 L190 47 L221 62 L266 68 L291 59 L294 76 L317 85 L314 103 L10 103 Z',
      cabin:'M108 64 L138 51 L184 51 L207 64 Z',
      trim:'M21 87 L288 85',
      extra:'<path d="M284 58 L309 58 L309 72 L279 72 M279 64 L284 46 L305 46" fill="none" stroke="#f6cc85" stroke-width="6"/><path d="M14 103 L72 103 M242 103 L311 103" stroke="#f5d6ab" stroke-width="5"/><path d="M109 76 L226 76" stroke="#fff4c1" stroke-width="6"/><path d="M141 52 L191 52" stroke="#111923" stroke-width="3"/>'
    }
  };
  const s = shapes[key] || shapes.rattler;
  return `<svg class="sr-eng-art sr-eng-art-${esc(key)}" role="img" aria-label="${esc(car.name)} fictional vehicle side-profile illustration" viewBox="0 0 330 135" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid meet">
    <defs><linearGradient id="paint-${esc(key)}" x1="0" x2="0" y1="0" y2="1"><stop stop-color="#fff" stop-opacity=".21"/><stop offset=".42" stop-color="${car.color}"/><stop offset="1" stop-color="${car.color}" stop-opacity=".66"/></linearGradient><linearGradient id="glass-${esc(key)}" x1="0" x2="1" y1="0" y2=".8"><stop stop-color="#b1ecfb" stop-opacity=".9"/><stop offset="1" stop-color="#17233b"/></linearGradient></defs>
    <ellipse cx="161" cy="115" rx="151" ry="12" fill="#050a14" opacity=".48"/>
    <path d="${s.shell}" fill="url(#paint-${esc(key)})" stroke="#131623" stroke-width="4" stroke-linejoin="round"/>
    <path d="${s.cabin}" fill="url(#glass-${esc(key)})" stroke="#e7eef2" stroke-width="3" stroke-linejoin="round"/>
    <path d="${s.trim}" fill="none" stroke="#e5eced" stroke-width="2.3" stroke-linecap="round"/>
    ${s.extra}
    <path d="M19 102 L311 102" stroke="#171725" stroke-width="4"/>
    ${[72,260].map(cx=>`<circle cx="${cx}" cy="103" r="25" fill="#12121b" stroke="#080a11" stroke-width="3"/><circle cx="${cx}" cy="103" r="16" fill="#444454" stroke="#f2e8d0" stroke-width="3"/><circle cx="${cx}" cy="103" r="8" fill="#d5d9dc"/><circle cx="${cx}" cy="103" r="3" fill="#565668"/>`).join('')}
    <path d="M17 89 h8 M308 86 h5" stroke="#fbe3ab" stroke-width="5"/>
    <text x="14" y="20" fill="#f5e9cb" font-family="system-ui,sans-serif" font-weight="800" font-size="13" letter-spacing="1">${esc(car.name.toUpperCase())}</text>
    <text x="314" y="20" text-anchor="end" fill="#b9ccda" font-family="system-ui,sans-serif" font-size="11">ORIGINAL CONCEPT</text>
  </svg>`;
}

function engineeringPanel() {
  const panel = document.createElement('section');
  panel.className='sr-eng sr-section';panel.id='sr-engineering-v2';
  panel.setAttribute('aria-label','Race engineering and setup');
  panel.innerHTML = `<header class="sr-eng-head"><div><span class="sr-eyebrow">TRACKSIDE ENGINEERING DIVISION</span><h3>Engineering V2</h3><p>Calculated longitudinal physics · fictional vehicle specifications · real saved setups</p></div><span class="sr-eng-version">MODELED • V2</span></header>
   <div class="sr-eng-showroom" id="sr-eng-showroom" aria-live="polite"></div>
   <div class="sr-eng-layout">
    <form id="sr-eng-form" class="sr-eng-form">
     <div class="sr-eng-title"><strong>Race setup sheet</strong><small id="sr-eng-tune-name">Select a car in your garage</small></div>
     <div class="sr-eng-controls">
       <label>Launch RPM <input id="sr-eng-launch" type="number" inputmode="numeric" step="50" required/><small id="sr-eng-launch-range"></small></label>
       <label>Final-drive multiplier <input id="sr-eng-fd" type="number" inputmode="decimal" min="0.84" max="1.18" step="0.01" required/><small id="sr-eng-fd-actual">Effective axle ratio</small></label>
       <label>Rear tire pressure (psi) <input id="sr-eng-psi" type="number" inputmode="decimal" min="20" max="42" step="0.5" required/><small>20–42 psi · modeled traction response</small></label>
       <label>Shift target RPM <input id="sr-eng-shift" type="number" inputmode="numeric" step="50" required/><small id="sr-eng-shift-range">Driver reference target</small></label>
     </div>
     <div class="sr-eng-actions"><button type="submit" class="sr-action sr-primary" id="sr-eng-save">Save race setup</button><button type="button" class="sr-action sr-outline" id="sr-eng-refresh">Refresh telemetry</button></div>
     <p id="sr-eng-save-status" role="status" aria-live="polite" class="sr-eng-message">Adjust between races. Your setup is stored separately for each owned car.</p>
    </form>
    <div class="sr-eng-telemetry"><div class="sr-eng-title"><strong>Last official V2 run</strong><small id="sr-eng-last-date">No finished V2 races yet</small></div><div id="sr-eng-results" class="sr-eng-tiles"><p class="sr-eng-muted">Make a run to see the timing slip.</p></div></div>
   </div>
   <details class="sr-eng-details"><summary>Race control data, engineering assumptions & physics version</summary><div id="sr-eng-raw" class="sr-eng-raw"></div></details>
   <div class="sr-eng-leaderboard"><div class="sr-eng-title"><strong>Engineered V2 standings</strong><small>V2 timing only. Original arcade records stay separate.</small></div><div id="sr-eng-leaders"></div></div>
   <p class="sr-eng-notes">All five cars are original, fictional designs. Figures are modeling assumptions, not manufacturer data. This is a longitudinal acceleration model, not a validated chassis dynamics simulator. Reaction time is separated from quarter-mile elapsed time. The shift-RPM field is a driver target, not an automatic transmission controller.</p>`;
  return panel;
}

const block = (label, value) => `<div class="sr-eng-tile"><span>${esc(label)}</span><strong>${esc(value)}</strong></div>`;
const selectedCar = data => (data?.cars || []).find(car=>car.selected)?.key || data?.cars?.[0]?.key || 'rattler';
let panel, client, data, mounting = false, loading = false, saving = false, userEditing = false;
let lastCar = '', lastTelemetryId = '', updateTimer = 0, periodic;

function showStatus(message, isError = false) {
  const node = document.getElementById('sr-eng-save-status');
  if (node) {node.textContent=message;node.dataset.error=String(isError);}
}
function updateAxleText() {
  const key = selectedCar(data);
  const spec = data?.engineering?.specs?.[key];
  const ratio = asNumber(document.getElementById('sr-eng-fd')?.value,1);
  const node = document.getElementById('sr-eng-fd-actual');
  if (node) node.textContent = `Effective axle ratio ≈ ${(asNumber(spec?.fd,3.55)*ratio).toFixed(2)}:1`; 
}
function paintArt(root) {
  if (!root) return;
  const owned = data?.cars || [];
  const cards = root.querySelectorAll('#sr-garage-cars .sr-car-card');
  (data?.catalog || []).forEach((model,i) => {
    const icon = cards[i]?.querySelector('.sr-car-pic');
    if (icon && icon.dataset.engArt !== model.key) {
      icon.innerHTML = carArtwork(model.key,'small');
      icon.dataset.engArt = model.key;
      if (owned.some(car=>car.key===model.key)) cards[i]?.classList.add('sr-eng-owned-car');
    }
  });
}
function paint(dataArg) {
  if (!panel || !dataArg) return;
  data = dataArg;
  const engineering = data.engineering || {};
  const key = selectedCar(data);
  const spec = engineering.specs?.[key];
  const car = CARS[key] || CARS.rattler;
  const owned = data.cars?.find(c=>c.key===key) || {};
  const red = asNumber(spec?.redline,5000);
  const tune = engineering.tunes?.[key] || {};
  const modelHp = Math.round(asNumber(spec?.hp,175)*(1+Math.min(5,asNumber(owned.engine))*.065));
  const showroom = document.getElementById('sr-eng-showroom');
  if (showroom) showroom.innerHTML=`<div class="sr-eng-visual">${carArtwork(key)}</div><div class="sr-eng-identity"><span class="sr-eyebrow">${esc(car.body)}</span><h4>${esc(car.name)}</h4><div class="sr-eng-specgrid">${block('Engine output',`${modelHp} modeled bhp`)}${block('Torque',`${formatNumber(asNumber(spec?.torque_nm))} Nm base`)}${block('Mass',`${formatNumber(asNumber(spec?.mass)+85)} kg with driver`)}${block('Redline',`${formatNumber(red)} RPM`)}${block('Wheelbase',`${asNumber(spec?.wheelbase).toFixed(2)} m`)}${block('Drag coefficient',asNumber(spec?.cd).toFixed(2))}</div></div>`;
  const form=document.getElementById('sr-eng-form');
  if (form && !userEditing && !saving && (lastCar!==key || !form.dataset.synced)) {
    document.getElementById('sr-eng-launch').value=Math.round(asNumber(tune.launch_rpm,clamp(Math.round(red*.54/50)*50,1600,red-500)));
    document.getElementById('sr-eng-fd').value=asNumber(tune.final_drive,1).toFixed(2);
    document.getElementById('sr-eng-psi').value=asNumber(tune.tire_pressure,29).toFixed(1);
    document.getElementById('sr-eng-shift').value=Math.round(asNumber(tune.shift_rpm,clamp(4800,Math.round(red*.65),red)));
    form.dataset.synced='yes'; lastCar=key;
  }
  const launch=document.getElementById('sr-eng-launch'), shift=document.getElementById('sr-eng-shift');
  if (launch) {launch.min='1600';launch.max=String(red-500);} if (shift) {shift.min=String(Math.round(red*.65));shift.max=String(red);}
  document.getElementById('sr-eng-launch-range').textContent=`1,600–${formatNumber(red-500)} RPM`;
  document.getElementById('sr-eng-shift-range').textContent=`${formatNumber(Math.round(red*.65))}–${formatNumber(red)} RPM · reference only`;
  document.getElementById('sr-eng-tune-name').textContent=`${car.name} · ${owned.engine||0}/5 engine · ${owned.tires||0}/5 tires · ${owned.gearbox||0}/5 gearbox`;
  updateAxleText();
  const latest=engineering.latest;
  const t=latest?.telemetry;
  if (t && t.physics_version==='engineered-v2') {
    const id=`${latest.car}/${latest.finished_at}/${t.total_ms}`;
    if (lastTelemetryId!==id) lastTelemetryId=id;
    const dt = new Date(latest.finished_at);
    const date = Number.isFinite(dt.valueOf()) ? new Intl.DateTimeFormat('en-US',{timeZone:'America/New_York',dateStyle:'medium',timeStyle:'short',hourCycle:'h23'}).format(dt) : 'Last recorded V2 run';
    document.getElementById('sr-eng-last-date').textContent=`${esc(CARS[latest.car]?.name || latest.car)} · ${date}`;
    document.getElementById('sr-eng-results').innerHTML=[
      block('QUARTER-MILE ET',formatTime(t.et_ms)),block('REACTION',formatTime(t.reaction_ms)),block('TOTAL',formatTime(t.total_ms)),
      block('TRAP SPEED',`${asNumber(t.trap_mph).toFixed(1)} mph`),block('60 FOOT',formatTime(t.sixty_ft_ms)),block('1/8 MILE',formatTime(t.half_track_ms)),
      block('PEAK G',`${asNumber(t.peak_g).toFixed(2)} g`),block('TRACTION LIMITED',`${formatNumber(t.traction_limited_pct)}%`),
      block('REDLINE STEPS',formatNumber(t.redline_steps))
    ].join('');
  } else {
    document.getElementById('sr-eng-last-date').textContent='No finished V2 races yet';
    document.getElementById('sr-eng-results').innerHTML='<p class="sr-eng-muted">Finish a race to generate a detailed timing slip.</p>';
  }
  const raw=document.getElementById('sr-eng-raw');
  if(raw && spec) raw.innerHTML=`<p><b>Physics:</b> 40 ms integration of engine torque and gearing, grip/load transfer, aerodynamic drag, rolling resistance, shift interruption and power boost. Model inputs are fictional and tunable.</p><p><b>Selected chassis:</b> base power ${formatNumber(spec.hp)} bhp, base torque ${formatNumber(spec.torque_nm)} Nm, tire radius ${asNumber(spec.radius).toFixed(3)} m, frontal area ${asNumber(spec.area).toFixed(2)} m², baseline axle ratio ${asNumber(spec.fd).toFixed(2)}:1, base tire μ ${asNumber(spec.mu).toFixed(2)}, rear static load ${(asNumber(spec.rear)*100).toFixed(0)}%. Four-speed gearbox ratios: ${spec.ratios?.map(v=>asNumber(v).toFixed(2)).join(' / ') || '—'}.</p><p><b>Model version:</b> ${esc(engineering.physics_version||'unknown')} · ${formatNumber(engineering.v2_races||0)} V2 races completed. Engine and gearbox upgrades affect simulated acceleration. Shift target is visual guidance only.</p>`;
  const leaders=engineering.v2_leaders||[];
  document.getElementById('sr-eng-leaders').innerHTML=leaders.length
    ? `<div class="sr-eng-table"><div class="sr-eng-row sr-eng-row-head"><span>Driver</span><span>Best total</span><span>Wins</span></div>${leaders.map((item,i)=>`<div class="sr-eng-row"><span><b>#${i+1}</b> ${esc(item.name)}</span><strong>${formatTime(item.best_ms)}</strong><span>${formatNumber(item.wins)}</span></div>`).join('')}</div>`
    : '<p class="sr-eng-muted">Be the first driver to set an Engineering V2 record.</p>';
  const originalLeaders=document.getElementById('sr-leaders');
  if(originalLeaders && !document.getElementById('sr-eng-legacy-note')) {
    const note=document.createElement('p');note.id='sr-eng-legacy-note';note.className='sr-eng-legacy-note';
    note.textContent='Historical all-time ranking includes original arcade runs and V2 runs. For comparable simulated results use the Engineering V2 standings above.';
    originalLeaders.before(note);
  }
  paintArt(document.getElementById('streetrod-root'));
}
async function fetchState() {
  if (!client || !panel || loading || saving || document.hidden) return;
  loading=true;
  try {
    const {data:member,error}=await client.rpc('community_streetrod_state');
    if (error) throw error;
    if (!member?.engineering || !member.engineering.specs) throw Error('Engineered V2 database is not yet available.');
    paint(member);
  } catch (e) {showStatus(e.message||'Unable to refresh the engineering data.',true);} finally {loading=false;}
}
async function saveSetup(event) {
  event.preventDefault();
  if (!client || !data || !panel || saving) return;
  const key=selectedCar(data),spec=data.engineering?.specs?.[key],red=asNumber(spec?.redline,5000);
  const launch=Number(document.getElementById('sr-eng-launch').value);
  const final=Number(document.getElementById('sr-eng-fd').value);
  const psi=Number(document.getElementById('sr-eng-psi').value);
  const shift=Number(document.getElementById('sr-eng-shift').value);
  const invalid = !Number.isInteger(launch) || !Number.isInteger(shift) ||
    !Number.isFinite(final) || !Number.isFinite(psi) || launch<1600 || launch>red-500 ||
    shift<Math.round(red*.65) || shift>red || final<.84 || final>1.18 || psi<20 || psi>42;
  if(invalid){showStatus('One or more settings fall outside this chassis’s approved range.',true);return;}
  saving=true;
  const button=document.getElementById('sr-eng-save');button.disabled=true;
  showStatus('Saving your setup…');
  try{
    const {data:updated,error}=await client.rpc('community_streetrod_tune',{
      p_car:key,p_launch_rpm:launch,p_final_drive:Number(final.toFixed(2)),
      p_tire_pressure:Number(psi.toFixed(1)),p_shift_rpm:shift
    });
    if(error) throw error;
    userEditing=false;
    const form=document.getElementById('sr-eng-form');if(form)delete form.dataset.synced;
    paint(updated);
    showStatus(`${CARS[key]?.name||key}: setup saved. Next race will use it.`);
  }catch(e){showStatus(e.message||'Unable to save your tuning setup.',true);}finally{saving=false;button.disabled=false;}
}

function scheduleUpdate(delay=600){clearTimeout(updateTimer);updateTimer=setTimeout(()=>{void fetchState()},delay);}
async function mount() {
  const root=document.getElementById('streetrod-root');
  if(!root || panel || mounting || !cfg?.enabled || !cfg?.supabaseUrl || !cfg?.publishableKey)return;
  const inside=root.querySelector('#sr-inside'), columns=root.querySelector('.sr-columns');
  if(!inside || !columns)return;
  mounting=true;
  if(!client){
    try{
      const {createClient}=await import('https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.118.0/+esm');
      const storage=createAuthStorage({local:window.localStorage,session:window.sessionStorage,remember:()=>window.localStorage.getItem('cowboy-community-remember')==='yes'});
      const storageKey='sb-'+new URL(cfg.supabaseUrl).hostname.split('.')[0]+'-auth-token';
      client=createClient(cfg.supabaseUrl,cfg.publishableKey,{auth:{storageKey,flowType:'pkce',persistSession:true,autoRefreshToken:false,detectSessionInUrl:false,storage}});
    }catch(error){mounting=false;return;}
  }
  panel=engineeringPanel();columns.before(panel);
  panel.querySelector('form').addEventListener('submit',saveSetup);
  panel.querySelector('form').addEventListener('input',()=>{userEditing=true;updateAxleText();});
  document.getElementById('sr-eng-refresh').addEventListener('click',()=>scheduleUpdate(0));
  root.addEventListener('click',ev=>{
    const action=ev.target.closest('[data-sr-action]')?.dataset.srAction;
    if(['select','buy','refresh','abandon'].includes(action)) {userEditing=false;lastCar='';scheduleUpdate(1100);}
  });
  const result=root.querySelector('#sr-result');
  if(result){
    const watcher=new MutationObserver(()=>{if(!result.hidden && result.querySelector('strong'))scheduleUpdate(1500);});
    watcher.observe(result,{childList:true,subtree:true});panel._srEngResultObserver=watcher;
  }
  const grid=root.querySelector('#sr-garage-cars');
  if(grid){
    const gridObserver=new MutationObserver(()=>{if(panel && data)paintArt(root);});
    gridObserver.observe(grid,{childList:true,subtree:true});
    panel._srEngGarageObserver=gridObserver;
  }
  await fetchState();
  mounting=false;
}
const observer=new MutationObserver(()=>{
  if(!document.getElementById('streetrod-root')) {
    if(panel){panel._srEngResultObserver?.disconnect();panel._srEngGarageObserver?.disconnect();panel=null;userEditing=false;data=null;lastCar='';}
  } else if(!panel) {void mount();}
});
if(cfg?.enabled && location.pathname.endsWith('/community.html')) {
  observer.observe(document.body,{childList:true,subtree:true});
  void mount();
  periodic=setInterval(()=>{if(!document.hidden && panel)void fetchState();},25000);
  document.addEventListener('visibilitychange',()=>{if(!document.hidden)scheduleUpdate(1000)});
}
