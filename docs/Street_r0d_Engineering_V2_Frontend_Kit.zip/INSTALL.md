# Cowboy’s Web Toolbox: Street r0d Engineering V2

## Current state

The live Supabase project `cowboys-web-toolbox-community` already has the V2 engine, V2 timing-slip history, private per-car tuning, and separately ranked V2 times deployed. DO NOT rerun the server migrations from this frontend package. The live website remains on its original frontend until this kit is uploaded and referenced.

## Install on the existing GitHub Pages site

Repo: https://github.com/perhardt7686/cowboys-web-toolbox
Deployment folder: https://github.com/perhardt7686/cowboys-web-toolbox/tree/main/docs
Target page: `docs/community.html`

1. Open the GitHub `docs` folder of the existing repository (or your current local checkout). Upload these two files into `docs` without changing other files:
   - `commons-streetrod-engineering.mjs`
   - `commons-streetrod-engineering.css`
2. Edit `docs/community.html`. Inside `<head>`, immediately after the existing `commons-streetrod.mjs` module tag, add these TWO lines exactly:

   ```html
   <link rel="stylesheet" href="commons-streetrod-engineering.css?v=eng2">
   <script type="module" src="commons-streetrod-engineering.mjs?v=eng2"></script>
   ```

3. Commit those changes to the default `main` branch. Existing free GitHub Pages deployment from `main` / `docs` will publish the update automatically.
4. Open https://perhardt7686.github.io/cowboys-web-toolbox/community.html and sign in as an approved Commons member.
5. Open Street r0d Racing and confirm you see the Engineering V2 setup sheet beneath the drag strip, five different concept-car profiles, the V2-only standings, and a timing slip after a completed V2 race.
6. With no race active, alter your selected car’s tire pressure or final-drive multiplier, press **Save race setup**, refresh, and confirm the values persisted. Run one race, then verify the V2 slip's quarter-mile ET and reaction time are distinct.

## Design choices and limitations

- All five vehicles are **fictional**. The car art is original, differentiated, vector-based concept art, not literal photos of production makes/models.
- The backend runs a 40 ms longitudinal model of wheel torque, traction, basic load transfer, drag, gearing, shift interruption, and optional boost. This is a game model, NOT a real-world performance certificate or complete race-engineering simulator.
- The **shift RPM** input is saved as your desired target and shown as guidance. The existing arcade track's animated REV meter is time-based, not yet a real-time engine RPM solver. Do not mistake the displayed dial for live physics telemetry.
- The original arcade leaderboard remains on the site. The V2 standings within the engineering panel exclude old physics-version runs to avoid invalid comparisons.
- The add-on reads your own garage and race data using the existing signed-in Supabase client configuration; server-side authorization remains enforced by the existing approved-member RPC.
- It is non-destructive: it adds a separate UI module, leaving the original game sources, profiles, credits, scores, and challenges untouched.

## Validation

- Static: the `.mjs` file passes `node --check` (ES module syntax) and its required integration controls are present.
- Backend: live database V2 migrations and simulation queries passed, including authorization grant checks.
- Full interactive, logged-in iPhone UI test and public-host deployment: **not completed** here.

## Why the front end was not committed automatically

The GitHub connector can read the repository, but its create-branch request returned `403 Resource not accessible by integration`. GitHub write access to this repository must be enabled or the uploaded files committed manually. The live backend did deploy successfully.
