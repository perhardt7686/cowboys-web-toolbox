THE COMMONS · FAMILY UPGRADE
===========================
Status: Backend installed and verified in the existing private Commons database.
Website resources are prepared, NOT yet published to GitHub Pages.

ONE-FILE PUBLISHING (same process you just used successfully)
1. In GitHub, open:
   https://github.com/perhardt7686/cowboys-web-toolbox/upload/main/.github/workflows
2. Upload commons-family-upgrade.yml (not this ZIP).
3. Choose Commit changes on the main branch.
4. GitHub Actions will install three board-only assets and modify docs/community.html.
5. Check Actions -> "Install Commons family game and drawing studio" for green Success.
6. Check Pages deployment for green Success. Then reload the Commons as an approved member.

WHAT IT ADDS
- High-contrast thread cards, larger message and reply type, improved author/avatar prominence.
- "Daily Word Quest": server-scored 5-letter team puzzle with hints, 12 shared guesses,
  individual total points, solves, all-time team wins, highest daily score, streaks.
  Only approved members can use the RPC. No user score records were created during installation.
- "The Drawing Studio": pen, brush, marker, eraser, shapes, text, eyedropper,
  background fill, palette, opacity, brush size, mirror, grid, editable layers,
  layer order and visibility, undo/redo, zoom, imported photos, local autosave,
  and downloadable PNG, JPEG, and editable project JSON.

PRIVACY
Board-only frontend. No Toolbox-wide theme changes. Approved member login remains required
for the word game. Drawings remain on the local device unless someone explicitly exports them.
The word-game answer bank and scores cannot be queried directly through public/anon database access.

TESTS PERFORMED
- Workflow YAML parsed and the embedded installer executed in an isolated temporary directory.
- Installed assets matched source bytes exactly.
- Both JavaScript modules passed Node 22 syntax checks.
- CSS parsed without syntax errors.
- Word-game database migrations and function grants verified.
- A signed-in browser end-to-end test was not possible in this environment.

If GitHub Actions fails, keep this README and ZIP. Nothing should be blindly retried or overwritten.
